
```bash

sudo apt-get install awscl


```



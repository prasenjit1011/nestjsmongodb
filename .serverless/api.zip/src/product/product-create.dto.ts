// src/product/dto/create-product.dto.ts
export class CreateProductDto {
    readonly name: string;
    readonly price: number;
    readonly description: string;
  }
  
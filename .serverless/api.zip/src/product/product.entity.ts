export class Product {}


```bash

sudo apt-get install awscl
npx serverless offline


```


